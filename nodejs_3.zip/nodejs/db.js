const knex = require('knex')({
    client: 'mysql2', // Use mysql2 instead of mysql
    connection: {
      host: '93.188.160.1',
      user: 'u700529020_yexah',
      password: 'Yexah@123',
      database: 'u700529020_yexah',
      authPlugins: {
        mysql_native_password: true,
      },
    },
  });
  
  module.exports = knex;
  